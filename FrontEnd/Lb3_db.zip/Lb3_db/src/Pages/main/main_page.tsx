import EmployeesTable from '../employees/employees';
import OrdersTable from '../orders/orders';
import EmployeeOrderCount from '../functions/employeeOrderCount';
import MostPopularBook from '../functions/mostPopularBook';
import './main_page.css';

const Main = () => {
  return (
    <div className="main-container">
      <div className="content-wrapper">
        
        <header className="app-header">
          <h1>Бібліотека</h1>
          <p>Управління співробітниками, замовленнями та аналітика</p>
        </header>

        <section className="functions-section">
          <h2>Аналітика (SQL функції)</h2>
          <div className="functions-grid">
            <EmployeeOrderCount />
            <MostPopularBook />
          </div>
        </section>

        <section className="section">
          <EmployeesTable />
        </section>

        <section className="section">
          <OrdersTable />
        </section>
      </div>
    </div>
  );
};

export default Main;