import { useState } from 'react';
import './addEmployeeForm.css';

interface AddEmployeeFormProps {
  onEmployeeAdded: () => void;
}

const AddEmployeeForm = ({ onEmployeeAdded }: AddEmployeeFormProps) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phoneNumber: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ text: '', type: '' });

    try {
      const response = await fetch('https://localhost:7015/api/Employees', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        throw new Error(`Ошибка: ${response.status}`);
      }

      const newEmployee = await response.json();
      setMessage({ 
        text: `Сотрудник "${newEmployee.firstName} ${newEmployee.lastName}" доданий!`, 
        type: 'success' 
      });

      setFormData({ firstName: '', lastName: '', phoneNumber: '' });

      onEmployeeAdded();
      
    } catch (error: any) {
      setMessage({ 
        text: `Помилка: ${error.message}`, 
        type: 'error' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="add-employee-form">
      <h3>Додати нового співробітника</h3>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Ім'я *</label>
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required
            minLength={2}
            maxLength={50}
            placeholder="Введіть ім'я"
            disabled={loading}
          />
        </div>

        <div className="form-group">
          <label>Фамилия *</label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required
            minLength={2}
            maxLength={50}
            placeholder="Введіть прізвище"
            disabled={loading}
          />
        </div>

        <div className="form-group">
          <label>Телефон *</label>
          <input
            type="tel"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleChange}
            required
            placeholder="+380XXXXXXXXX"
            pattern="\+380[0-9]{9}"
            title="Формат: +380XXXXXXXXX"
            disabled={loading}
          />
        </div>

        <button 
          type="submit" 
          disabled={loading}
          className="submit-btn"
        >
          {loading ? 'Додавання...' : 'Додати співробітника'}
        </button>

        {message.text && (
          <div className={`message ${message.type}`}>
            {message.text}
          </div>
        )}
      </form>
    </div>
  );
};

export default AddEmployeeForm;