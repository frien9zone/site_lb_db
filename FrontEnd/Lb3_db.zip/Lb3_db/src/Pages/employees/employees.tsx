import { useState, useEffect } from 'react';
import './employees.css';
import AddEmployeeForm from './addEmployeeForm';

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
}

const EmployeesTable = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  const loadEmployees = async () => {
    try {
      const response = await fetch('https://localhost:7015/api/Employees');
      if (!response.ok) throw new Error('Ошибка загрузки сотрудников');
      const data = await response.json();
      setEmployees(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, [refreshKey]);

  const handleEmployeeAdded = () => {
    setRefreshKey(prev => prev + 1);
  };

  if (loading) return <div className="loading">Завантаження співробітників...</div>;
  if (error) return <div className="error">Помилка: {error}</div>;

  return (
    <div className="employees-section">
      <h2>Співробітники бібліотеки</h2>

      <AddEmployeeForm onEmployeeAdded={handleEmployeeAdded} />

      <table className="employees-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Ім'я</th>
            <th>Прізвище</th>
            <th>Телефон</th>
          </tr>
        </thead>
        <tbody>
          {employees.map(emp => (
            <tr key={emp.id}>
              <td>{emp.id}</td>
              <td>{emp.firstName}</td>
              <td>{emp.lastName}</td>
              <td>{emp.phoneNumber}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="employees-count">Всього сотрудників: {employees.length}</div>
    </div>
  );
};

export default EmployeesTable;