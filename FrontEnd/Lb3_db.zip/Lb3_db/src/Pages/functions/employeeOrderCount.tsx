import { useState } from 'react';
import './functions.css';

const EmployeeOrderCount = () => {
  const [employeeId, setEmployeeId] = useState('');
  const [orderCount, setOrderCount] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchOrderCount = async () => {
    if (!employeeId.trim()) {
      setError('Введіть ID працівника');
      return;
    }

    setLoading(true);
    setError('');
    setOrderCount(null);

    try {
      const response = await fetch(
        `https://localhost:7015/api/functions/employee-order-count/${employeeId}`
      );
      
      if (!response.ok) {
        throw new Error('Ошибка загрузки данных');
      }

      const data = await response.json();
      setOrderCount(data.orderCount);
    } catch (err: any) {
      setError(err.message || 'Произошла ошибка');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchOrderCount();
  };

  return (
    <div className="function-card">
      <h3>Кількість замовлень працівника</h3>
      
      <form onSubmit={handleSubmit} className="function-form">
        <div className="input-group">
          <label>ID робітника:</label>
          <input
            type="number"
            value={employeeId}
            onChange={(e) => setEmployeeId(e.target.value)}
            placeholder="Введіть ID"
            min="1"
            required
          />
        </div>
        
        <button type="submit" disabled={loading}>
          {loading ? 'Завантаження...' : 'Показати'}
        </button>
      </form>

      {error && <div className="error-message">{error}</div>}

      {orderCount !== null && (
        <div className="result-box">
          <h4>Результат:</h4>
          <p>Робітник с ID <strong>{employeeId}</strong> виконав</p>
          <div className="count-display">{orderCount}</div>
          <p>заказ(ів)</p>
        </div>
      )}
    </div>
  );
};

export default EmployeeOrderCount;