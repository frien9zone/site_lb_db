import { useState, useEffect } from 'react';
import './functions.css';

interface MostPopularBook {
  bookId: number;
  bookTitle: string;
  author: string;
  genre: string;
  releaseYear: number;
  orderCount: number;
}

const MostPopularBook = () => {
  const [book, setBook] = useState<MostPopularBook | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchMostPopularBook();
  }, []);

  const fetchMostPopularBook = async () => {
    try {
      const response = await fetch('https://localhost:7015/api/functions/most-popular-book');
      
      if (!response.ok) {
        throw new Error('Ошибка загрузки данных');
      }

      const data = await response.json();
      setBook(data);
    } catch (err: any) {
      setError(err.message || 'Произошла ошибка');
    } finally {
      setLoading(false);
    }
  };

  const refreshData = () => {
    setLoading(true);
    fetchMostPopularBook();
  };

  if (loading) return <div className="loading">Загрузка данных о самой популярной книге...</div>;
  if (error) return <div className="error">Ошибка: {error}</div>;

  return (
    <div className="function-card">
      <div className="card-header">
        <h3>Найпопулярніша книга</h3>
        <button onClick={refreshData} className="refresh-btn">Оновити</button>
      </div>
      
      {book ? (
        <div className="popular-book-card">
          
          <div className="book-info">
            <h4>{book.bookTitle}</h4>
            <p><strong>Автор:</strong> {book.author}</p>
            <p><strong>Жанр:</strong> {book.genre}</p>
            <p><strong>Рік видання:</strong> {book.releaseYear}</p>
            <p><strong>ID кніги:</strong> {book.bookId}</p>
          </div>
          
          <div className="order-stats">
            <div className="stat-number">{book.orderCount}</div>
            <div className="stat-label">заказ(ів)</div>
          </div>
        </div>
      ) : (
        <p>Немає даних про книгух</p>
      )}
    </div>
  );
};

export default MostPopularBook;