import { useState, useEffect } from 'react';
import './orders.css';

interface Order {
  id: number;
  customerId: number;
  bookId: number;
  quantity: number;
  employeeId: number;
  orderDate: string;
}

const OrdersTable = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadOrders = async () => {
      try {
        const response = await fetch('https://localhost:7015/api/Orders');
        if (!response.ok) throw new Error('Помилка загрузки заказів');
        const data = await response.json();
        setOrders(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadOrders();
  }, []);

  if (loading) return <div className="loading">Підвантаженя</div>;
  if (error) return <div className="error">Помилка: {error}</div>;

  return (
    <div className="orders-section">
      <h2>Замовлення</h2>
      <table className="orders-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>ID Кліента</th>
            <th>ID Книги</th>
            <th>Кількість</th>
            <th>ID Працівника</th>
            <th>Дата заказа</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.customerId}</td>
              <td>{order.bookId}</td>
              <td>{order.quantity}</td>
              <td>{order.employeeId}</td>
              <td>{new Date(order.orderDate).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="orders-count">Всього заказів: {orders.length}</div>
    </div>
  );
};

export default OrdersTable;