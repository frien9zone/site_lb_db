export interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
}

const API_BASE_URL = 'https://localhost:7015/api';

export const employeeApi = {
  // Получить всех сотрудников
  getAll: async (): Promise<Employee[]> => {
    const response = await fetch(`${API_BASE_URL}/Employees`);
    if (!response.ok) {
      throw new Error(`Ошибка HTTP: ${response.status}`);
    }
    return response.json();
  },

  // Получить сотрудника по ID (опционально, если понадобится)
  getById: async (id: number): Promise<Employee> => {
    const response = await fetch(`${API_BASE_URL}/Employees/${id}`);
    if (!response.ok) {
      throw new Error(`Ошибка HTTP: ${response.status}`);
    }
    return response.json();
  }
};