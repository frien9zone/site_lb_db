﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using db_site.Models;

namespace db_site.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public OrdersController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /api/orders
        [HttpGet]
        public async Task<IActionResult> GetAllOrders()
        {
            var orders = await _context.Orders.ToListAsync();
            return Ok(orders);
        }

        // GET: /api/orders/employee/{employeeId}
        [HttpGet("employee/{employeeId}")]
        public async Task<IActionResult> GetOrdersByEmployee(int employeeId)
        {
            var orders = await _context.Orders
                .Where(o => o.EmployeeId == employeeId)
                .ToListAsync();

            return Ok(orders);
        }

        // POST: /api/orders
        [HttpPost]
        public async Task<IActionResult> AddOrder([FromBody] AddOrderRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var sql = @"
            INSERT INTO Orders (customerId, bookId, quantity, employeeId, orderDate)
            VALUES ({0}, {1}, {2}, {3}, {4})";

                await _context.Database.ExecuteSqlRawAsync(sql,
                    request.CustomerId,
                    request.BookId,
                    request.Quantity,
                    request.EmployeeId,
                    request.OrderDate);

                var lastOrder = await _context.Orders
                    .OrderByDescending(o => o.Id)
                    .FirstOrDefaultAsync();

                return CreatedAtAction(nameof(GetAllOrders), lastOrder);
            }
            catch (SqlException sqlEx) when (sqlEx.Number == 50000)
            {
                return BadRequest(new
                {
                    error = "Ошибка добавления заказа",
                    message = sqlEx.Message
                });
            }
            catch (SqlException sqlEx)
            {
                return BadRequest(new
                {
                    error = "Ошибка SQL Server",
                    message = sqlEx.Message,
                    errorNumber = sqlEx.Number
                });
            }
        }
    }
}