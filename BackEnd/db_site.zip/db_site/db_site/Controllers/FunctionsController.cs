﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using db_site.Models;

namespace db_site.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FunctionsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public FunctionsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /api/functions/employee-order-count/{employeeId}
        [HttpGet("employee-order-count/{employeeId}")]
        public IActionResult GetEmployeeOrderCount(int employeeId)
        {
            var parameter = new SqlParameter("@EmployeeId", employeeId);
            
            // Вызов скалярной функции
            var count = _context.Database
                .SqlQueryRaw<int>("SELECT dbo.GetEmployeeOrderCount(@EmployeeId)", parameter)
                .AsEnumerable()
                .FirstOrDefault();

            return Ok(new { EmployeeId = employeeId, OrderCount = count });
        }

        // GET: /api/functions/most-popular-book
        [HttpGet("most-popular-book")]
        public IActionResult GetMostPopularBook()
        {
            var popularBook = _context.Database
                .SqlQueryRaw<MostPopularBook>("SELECT * FROM dbo.GetMostPopularBook()")
                .AsEnumerable()
                .FirstOrDefault();

            if (popularBook == null)
            {
                return NotFound("Нет данных о книгах");
            }

            return Ok(popularBook);
        }
    }
}