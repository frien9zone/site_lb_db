﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using db_site.Models;

namespace db_site.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /api/employees
        [HttpGet]
        public async Task<IActionResult> GetAllEmployees()
        {
            var employees = await _context.Employees.ToListAsync();
            return Ok(employees);
        }

        // GET: /api/employees/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployeeById(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound("Работник не найден");
            }
            return Ok(employee);
        }

        // GET: /api/employees/{id}/orders
        [HttpGet("{id}/orders")]
        public async Task<IActionResult> GetEmployeeWithOrders(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound("Работник не найден");
            }

            var orders = await _context.Orders
                .Where(o => o.EmployeeId == id)
                .ToListAsync();

            return Ok(new
            {
                Employee = employee,
                Orders = orders
            });
        }

        // POST: /api/employees
        [HttpPost]
        public async Task<IActionResult> AddEmployee([FromBody] AddEmployeeRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var sql = @"
            INSERT INTO Employees (firstName, lastName, phoneNumber)
            VALUES ({0}, {1}, {2})";

                await _context.Database.ExecuteSqlRawAsync(sql,
                    request.FirstName,
                    request.LastName,
                    request.PhoneNumber);

                var lastEmployee = await _context.Employees
                    .OrderByDescending(e => e.Id)
                    .FirstOrDefaultAsync();

                if (lastEmployee == null)
                {
                    return Ok(new { message = "Сотрудник добавлен" });
                }

                return Ok(lastEmployee);
            }
            catch (SqlException sqlEx) when (sqlEx.Number == 50000)
            {
                return BadRequest(new
                {
                    error = "Ошибка добавления сотрудника",
                    message = sqlEx.Message
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}