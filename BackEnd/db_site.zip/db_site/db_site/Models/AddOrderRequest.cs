﻿using System;
using System.ComponentModel.DataAnnotations;

namespace db_site.Models
{
    public class AddOrderRequest
    {
        [Required(ErrorMessage = "ID клиента обязателен")]
        [Range(1, int.MaxValue, ErrorMessage = "ID клиента должен быть положительным числом")]
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "ID книги обязателен")]
        [Range(1, int.MaxValue, ErrorMessage = "ID книги должен быть положительным числом")]
        public int BookId { get; set; }

        [Required(ErrorMessage = "Количество обязательно")]
        [Range(1, 100, ErrorMessage = "Количество должно быть от 1 до 100")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "ID работника обязателен")]
        [Range(1, int.MaxValue, ErrorMessage = "ID работника должен быть положительным числом")]
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Дата заказа обязательна")]
        public DateTime OrderDate { get; set; }
    }
}