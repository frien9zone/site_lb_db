﻿namespace db_site.Models
{
    public class MostPopularBook
    {
        public int BookId { get; set; }
        public string BookTitle { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string Genre { get; set; } = string.Empty;
        public int ReleaseYear { get; set; }
        public int OrderCount { get; set; }
    }
}