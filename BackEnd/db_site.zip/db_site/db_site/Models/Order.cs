﻿using System;

namespace db_site.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int BookId { get; set; }
        public int Quantity { get; set; }
        public int EmployeeId { get; set; }
        public DateTime OrderDate { get; set; }
    }
}